import numpy as np
#want v in gaussian
def getMomentum(r, v):
    return np.cross(r, v)

#returns degrees
import math as m
def getAngle(cosine, sine):
    initialAcos = m.acos(cosine)
    initialAsin = m.asin(sine)
    if (abs(cosine**2 + sine**2 - 1) > 0.1):
        return "error"
    else:
        result = 0
        if (sine == 0 and cosine == 1):
            result = 0
        elif (sine == 1 and cosine == 0):
            result = m.pi*0.5
        elif (sine == 0 and cosine == -1):
            result = m.pi
        elif (sine == -1 and cosine == 0):
            result = 1.5*m.pi
        elif (sine > 0 and cosine > 0):
            result = abs(initialAsin)
        elif (sine > 0 and cosine < 0):
            result = initialAcos
        elif (sine < 0 and cosine < 0):
            result = 1*m.pi + abs(initialAsin)
        elif (sine < 0 and cosine > 0):
            result = 2*m.pi-abs(initialAsin)
    return m.degrees(result)

def getPerihelion(rDotVec, hVec):
    return np.cross(-1*hVec, rDotVec) - np.linalg.norm(rDotVec)

def getA(rVec, rDotVec):
    return 1/((2/np.linalg.norm(rVec))-np.linalg.norm(rDotVec)**2)

#RETURNS IN DEGREES!!!!
def getInclination(hVec):
    return np.degrees(np.arctan(np.sqrt(hVec[0]**2 + hVec[1]**2)/hVec[2]))

def getEccentricity(hVec, a):
    return np.sqrt(1-(np.linalg.norm(hVec)**2/a))

# RETURNS IN DEGREES
def getLongitudeOfAscendingNode(hVec, iDegrees):
    cosOmega = -hVec[1]/(np.linalg.norm(hVec)*np.sin(np.radians(iDegrees)))
    sinOmega = hVec[0]/(np.linalg.norm(hVec)*np.sin(np.radians(iDegrees)))
    return getAngle(cosOmega, sinOmega)

def getTrueAnomaly(a, e, hVec, rVec, rDotVec):
    rMag = np.linalg.norm(rVec)
    hMag = np.linalg.norm(hVec)
    sinV = ((a*(1 - e**2))/(e*hMag))*((np.dot(rVec, rDotVec))/rMag)
    # print("sinV:", sinV)
    cosV = (1/e)*(((a*(1 - e**2))/rMag) - 1)
    # print("cosV:", cosV)
    return getAngle(cosV, sinV)

def getArgOfPerihelion(tAnomaly, rVec, LAN, i):
    x = rVec[0]
    y = rVec[1]
    z = rVec[2]
    rMag = np.linalg.norm(rVec)
    omega = np.radians(LAN)

    cosU = (x*np.cos(omega) + y*np.sin(omega))/rMag
    sinU = z/(rMag*np.sin(np.radians(i)))
    # print(sinU)

    u = getAngle(cosU, sinU)
    initialArg = np.radians(u)-np.radians(tAnomaly)
    while initialArg < 0:
        initialArg = initialArg + 2*np.pi
    while initialArg > 2*np.pi:
        initialArg = initialArg - 2*np.pi
    return np.degrees(initialArg)
    
def lspr(fileName, x, y):
    file = open(fileName)
    info = np.loadtxt(file, str)

    #getting the RA column and turning it into a list
    iStarRAs = info[:, 2:3]
    iStarRAs = np.transpose(iStarRAs)[0]

    starRAs = []
    #converting into decimal hours
    for i in range(0, len(iStarRAs)):
        # sum = float(iStarRAs[i][:2])*15 + float(iStarRAs[i][3:5])*0.25 + float(iStarRAs[i][6:])*0.25/60
        # starRAs.append(float(sum))
        starRAs.append(float(iStarRAs[i]))
    # print(len(starRAs))

    iStarDecs = info[:, 3:]
    iStarDecs = np.transpose(iStarDecs)[0]
    
    starDecs = []
    #converting into decimal degrees
    for i in range(0, len(iStarDecs)):
        # coef = 1
        # if (iStarDecs[i][0] == "-"):
        #     coef = -1
        # sum = float(iStarDecs[i][1:3]) + float(iStarDecs[i][4:6])/60 + float(iStarDecs[i][7:])/3600
        starDecs.append(float(iStarDecs[i]))
    print(starDecs)

    #converting star x's into a list
    iStarXs = info[:, :1]
    iStarXs = np.transpose(iStarXs)[0]
    starXs = []
    for i in range(0, len(iStarXs)):
        starXs.append(float(iStarXs[i]))
    # print(starXs)

    #converting star y's into a list
    iStarYs = info[:, 1:2]
    iStarYs = np.transpose(iStarYs)[0]
    starYs = []
    for i in range(0, len(iStarYs)):
        starYs.append(float(iStarYs[i]))
    # print(starYs)

    #making x square and y square sums
    xSquareSum = np.sum(np.array(starXs)*np.array(starXs))

    ySquareSum = np.sum(np.array(starYs)*np.array(starYs))

    xySum = np.sum(np.array(starXs)*np.array(starYs))

    starYs = np.array(starYs)
    starXs = np.array(starXs)
    starRAs = np.array(starRAs)
    starDecs = np.array(starDecs)
    # print(starRAs)

    #creating first matrix
    xyMatrix = np.array([[len(starRAs), np.sum(starXs), np.sum(starYs)], [np.sum(starXs), xSquareSum, xySum], 
                                   [np.sum(starYs), xySum, ySquareSum]])

    xyMatrix = np.linalg.inv(xyMatrix)
    
    raMatrix = np.array([[np.sum(starRAs)], [np.sum(starRAs*starXs)], 
                        [np.sum(starRAs*starYs)]])
    
    decMatrix = np.array([[np.sum(starDecs)], [np.sum(starDecs*starXs)], 
                        [np.sum(starDecs*starYs)]])
    
    raAnswers = np.dot(xyMatrix, raMatrix)
    decAnswers = np.dot(xyMatrix, decMatrix)

    # print(raAnswers)
    # print(decAnswers)

    RA = raAnswers[0] + raAnswers[1]*x + raAnswers[2]*y
    Dec = decAnswers[0] + decAnswers[1]*x + decAnswers[2]*y

    uSumRA = 0
    for i in range(0, len(starRAs)):
        uSumRA = uSumRA + (starRAs[i] - raAnswers[0] - raAnswers[1]*starXs[i] - raAnswers[2]*starYs[i])**2
    
    uSumDec = 0
    errorList = []
    for i in range(0, len(starDecs)):
        uSumDec = uSumDec + (starDecs[i] - decAnswers[0] - decAnswers[1]*starXs[i] - decAnswers[2]*starYs[i])**2
        errorList.append((starDecs[i] - decAnswers[0] - decAnswers[1]*starXs[i] - decAnswers[2]*starYs[i])*3600)
    
    print(errorList, "<------ the error list")
    raU = np.sqrt(uSumRA/(len(starRAs) - 3))
    decU = np.sqrt(uSumDec/(len(starDecs) - 3))
    
    # print(decU*3600, "decu")
    # print(raU*3600, "raU")

    # print(RA)
    # print(Dec)

    RA = RA[0]
    Dec = Dec[0]

    RA = RA*24/360
    # print(RA)
    RAhours = int(RA)
    RAminutes = int((RA - RAhours)*60)
    RAseconds = round(3600*(RA - RAhours - RAminutes/60), 3)
    raString = str(RAhours)+":"+str(RAminutes)+":"+str(RAseconds)

    decHours = int(Dec)
    decMinutes = int((Dec - decHours)*60)
    decSeconds = round(3600*(Dec - decHours - decMinutes/60), 3)
    decString = str(decHours)+":"+str(decMinutes)+":"+str(decSeconds)

    print("*"*14)
    print("plate constants")
    print("*"*14)
    print("b1:", raAnswers[0][0], "deg")
    print("b2:", decAnswers[0][0], "deg")
    print("a11:", raAnswers[1][0], "deg/pix")
    print("a12:", raAnswers[2][0], "deg/pix")
    print("a21:", decAnswers[1][0], "deg/pix")
    print("a22:", decAnswers[2][0], "deg/pix")
    print("*"*11)
    print("uncertainty")
    print("*"*11)
    print(" RA:", round(3600*raU[0], 3), "arcsec")
    print("Dec:", round(3600*decU[0], 3), "arcsec")
    print("*"*25)
    print("astrometry for")
    print("(x, y) =", x, y)
    print("*"*25)
    print(" RA =", raString)
    print("Dec =", decString)

# mInitial = 0.42
# eInitial = 0.8
# tolerance = 0.00000000001
def newtonRaphson(m, e, tol):
    oldEtest = m
    ETest = oldEtest - (oldEtest - e*np.sin(oldEtest) - m)/(-e*np.cos(oldEtest) + 1)
    iterationNum = 0
    while (abs(ETest - oldEtest) > tol):
        iterationNum = iterationNum + 1
        oldEtest = ETest
        ETest = oldEtest - (oldEtest - e*np.sin(oldEtest) - m)/(-e*np.cos(oldEtest) + 1)
    # print("E: ", ETest)
    # print("Tolerance: ", tol)
    # print("Iterations: ", iterationNum)
    return ETest

#time is a string- hh:mm:ss
def julian(isLocalTime, yr, month, day, time):
    term1 = (month+9)//12
    term2 = 7*(term1 + yr)//4
    julianAt0 = 367*yr - term2 + 275*month//9 + day + 1721013.5
    UT = float(time[0:2])+ float(time[3:5])/60 + float(time[6:8])/3600
    if isLocalTime:
        UT = UT + 4
    return julianAt0  + UT/24
# print(julian(False, 2018, 7, 13, "00:00:00"))

#returns in degrees!!!!!!!!
def getMeanAnomaly(rVec, a, e):
    r = np.linalg.norm(rVec)
    E0 = np.arccos((1/e)*(1-(r/a)))
    return np.degrees(E0 - e*np.sin(E0))

def getTimeOfLastPerihelion(meanAnomaly, a, julianDate):
    k = 0.01720209895
    return -1*((np.radians(meanAnomaly)/np.sqrt((k**2)/(a**3))) - julianDate)

def convertToDecimalHours(stringToConvert, hasSign, toDegrees):
    coef = 1
    sum = 0
    if(hasSign):
        if (stringToConvert[0] == "-"):
            coef = -1
        sum = coef*(float(stringToConvert[1:3]) + float(stringToConvert[4:6])/60 + float(stringToConvert[7:])/3600)
    else:
        sum = float(stringToConvert[:2]) + float(stringToConvert[3:5])/60 + float(stringToConvert[6:])/3600
    if(toDegrees):
        sum = sum*360/24
    return sum

def getRaAndDec(a, eccentricity, timePerihelion, inclination, LAN, argOfPerihelion, currentTimeJulian, earthSunVec):
    k = 0.01720209895
    n = k*np.sqrt(1/(a**3))
    initialM = n*(currentTimeJulian - timePerihelion)
    E = newtonRaphson(initialM, eccentricity, 0.000000001) #may change tolerance

    inclination = np.radians(inclination)
    LAN = np.radians(LAN)
    argOfPerihelion = np.radians(argOfPerihelion)

    x = a*np.cos(E) - a*eccentricity
    y = a*np.sqrt(1-eccentricity**2)*np.sin(E)
    z = 0

    posVec = np.array([[x], [y], [z]])
    matrix1 = np.array([[np.cos(LAN), -np.sin(LAN), 0], [np.sin(LAN), np.cos(LAN), 0], [0, 0, 1]])
    matrix2 = np.array([[1, 0, 0], [0, np.cos(inclination), -np.sin(inclination)], [0, np.sin(inclination), np.cos(inclination)]])
    matrix3 = np.array([[np.cos(argOfPerihelion), -np.sin(argOfPerihelion), 0], [np.sin(argOfPerihelion), np.cos(argOfPerihelion), 0], [0, 0, 1]])

    newVector = np.matmul(matrix1, np.matmul(matrix2, np.matmul(matrix3, posVec)))
    epsilon = np.radians(23.44)
    rotationMatrix = np.array([[1, 0, 0], [0, np.cos(epsilon), -np.sin(epsilon)], [0, np.sin(epsilon), np.cos(epsilon)]])
    equitorialPosition = np.matmul(rotationMatrix, newVector)
    rangeVec = equitorialPosition + earthSunVec
    # print("rangevec: ", rangeVec)
    pHat = rangeVec/np.linalg.norm(rangeVec)
    # print(pHat)

    Dec = np.arcsin(pHat[2][0])
    RA = getAngle(pHat[0][0]/np.cos(Dec), pHat[1][0]/np.cos(Dec))
    return RA, np.degrees(Dec)
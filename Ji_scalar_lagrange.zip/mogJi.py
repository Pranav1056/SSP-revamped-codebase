import numpy as np

def scaleEqLagrange(tauVec, sunVec, rhoHatVec, dsVec):
    tauVec = np.array(tauVec)
    sunVec = np.array(sunVec)
    rhoHatVec = np.array(rhoHatVec)
    dsVec = np.array(dsVec)

    mu = 1
    tau = tauVec[2][0]-tauVec[0][0]
    A1 = tauVec[2][0]/tau
    B1 = (A1/6)*((tau**2) - (tauVec[2][0]**2))
    A3 = -tauVec[0][0]/tau
    B3 = (A3/6)*((tau**2) - (tauVec[0][0]**2))

    A = (A1*dsVec[1][0] - dsVec[2][0] + A3*dsVec[3][0])/(-dsVec[0][0])
    B = (B1*dsVec[1][0] + B3*dsVec[3][0])/(-dsVec[0][0])

    E = (rhoHatVec[0][0]*sunVec[0][0] + rhoHatVec[1][0]*sunVec[1][0] + rhoHatVec[2][0]*sunVec[2][0])*-2
    F = (np.linalg.norm(sunVec))**2
    a = -((A**2) + A*E  + F)
    b = -mu*(2*A*B + B*E)
    c = -(mu**2)*(B**2)

    # print([c, 0, 0, b[0], 0, 0, a[0], 0, 1])
    # print(a, b, c)

    answers = np.roots([c, 0, 0, b, 0, 0, a, 0, 1])

    return answers

    #d0, d21, d22, d23
    #u need lowercase a, b, c

print(scaleEqLagrange([[-0.15481889055], [0.15481889055], [0.3096377811]], 
                [[-0.2398478458274071], [0.9065739917845802], [0.3929623749770952]], 
                [[-0.8518563498182248], [-0.2484702599212149], [0.4610892421311239]], 
                [[-0.0010461861084885213], [-0.17297581974209159], [-0.17201260125558127], [-0.16712421570714076]]))
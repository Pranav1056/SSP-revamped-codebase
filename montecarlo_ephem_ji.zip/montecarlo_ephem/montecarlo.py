import numpy as np
import time

def simulate():
    numDotsInCircle = 0
    for i in range (10000):
        if (np.random.random()*2 - 1)**2 + (np.random.random()*2 - 1)**2 <= 1:
            numDotsInCircle = numDotsInCircle+1
    piGuess = 4*(numDotsInCircle/10000)
    return piGuess

def iterate(num):
    results = []
    for i in range(0, num):
        results.append(simulate())
    results = np.array(results)
    mean = np.mean(results)
    stDev = np.std(results)
    sdom = mean/np.sqrt(num)
    error = abs(np.pi-mean)/np.pi
    return results, mean, stDev, sdom, error*100

print(iterate(30))
        